---
title: "HTTPie - a command-line HTTP client with a friendly UI"
tags: "Uncategorized"
date: "2019-08-17"
---

![](images/httpie.gif)

JSON support, syntax highlighting, wget-like downloads, plugins, and more

[more info](https://httpie.org)
