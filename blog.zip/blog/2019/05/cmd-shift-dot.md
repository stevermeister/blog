---
title: "Cmd + Shift + . (dot)"
tags: "Uncategorized"
date: "2019-05-24"
---

Yesterday I got know that this shortcut toggle visibility of "dotted" files on mac, it made my day. Previously I had to use either additional apps or special mac options that was possible to change only via terminal.
