---
title: "All Electric Car Comparison - Spreadsheet"
tags: "Uncategorized"
date: "2019-05-08"
---

There are so much information about different vehicles that I decided to create my [own table](https://docs.google.com/spreadsheets/d/16DSoOxg77jkqe-g9_2uZ0B9pAtT4ZWg-qlXeeRXqL_A/edit?usp=sharing) and collect all information there.

![](images/Electric_charge_types.jpg)

You are more than welcome to add information.
