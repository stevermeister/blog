---
title: "Carbon - service to make \"codeshots\""
tags: "Uncategorized"
date: "2019-05-03"
---

One more service to bookmarks, finally I have something simple to make code snapshots for presentation.

[![](images/Screenshot-2019-05-03-at-10.32.48.png)](https://carbon.now.sh/?bg=rgba(171%2C%20184%2C%20195%2C%201)&t=monokai&wt=none&l=auto&ds=true&dsyoff=20px&dsblur=68px&wc=true&wa=true&pv=56px&ph=56px&ln=false&fm=Hack&fs=14px&lh=133%25&si=false&es=2x&wm=false)
