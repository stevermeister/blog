---
title: "Array.prototype.map()"
tags: "javascript"
date: "2013-02-26"
---

Жду недождусь когда уже в продакшене можно будет использовать метод **map()** для массивов.

А пока его нет приходится использовать что-то такое:

# [Array.prototype.map()](https://developer.mozilla.org/en-US/docs/JavaScript/Reference/Global_Objects/Array/map#Compatibility)

или такое

[**_.map()**](https://underscorejs.ru/#map)
