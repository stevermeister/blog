---
title: "GeoGuessr - угадываем своё местоположение"
tags: "map,online,Рекомендую"
date: "2013-06-24"
---

[![](images/Screen-Shot-2013-06-24-at-8.51.45-AM-300x35.png "geoguessr logo")](https://www.geoguessr.com/)

прекрасный стартапчик с использованием google street view. и он мне до сих пор не надоел - рекомендую.
