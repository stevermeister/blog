---
title: "Scrum board"
tags: "online,scrum,Рекомендую"
date: "2013-06-14"
---

[![](images/Screen-Shot-2013-06-14-at-6.40.46-PM-300x154.png "scrumblr")](https://scrumblr.ca/)

Симпатичная дружелюбная [опен-сорс](https://github.com/aliasaria/scrumblr) утилита для организации Scum-доски прогресса юзерстори/заданий.
