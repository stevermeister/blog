---
title: "FirefoxOS телефоны"
tags: "FirefoxOS,javascript,phone,Рекомендую"
date: "2013-06-25"
---

![](images/pic_home-257x300.jpg "pic_home")

JavaScript-программируемые телефоны с [FirefoxOS](https://developer.mozilla.org/en/docs/Mozilla/Firefox_OS) на борту [уже в продаже](https://shop.geeksphone.com/en/#buy-it). Мне посчасливилось поиграться обеими моделями. Первое впечатление - очень сыроват интерфейс. Но сама возможность управления звонками, сообщениями и телефонной книгой используя только JavaScript подталкивает к нажатию на кнопочку buy.
