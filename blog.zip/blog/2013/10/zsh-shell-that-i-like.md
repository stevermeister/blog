---
title: "Zsh - shell that I like"
tags: "shell,zsh,Рекомендую"
date: "2013-10-23"
---

The main thing why I switched to **zsh** is **git branch name** output for directories that have git. Of course, there are many other things inside.

install:

```
curl -L github.com/robbyrussell/oh-my-zsh/raw/master/tools/install.sh | sh
```


uninstall

```
uninstall_oh_my_zsh
```