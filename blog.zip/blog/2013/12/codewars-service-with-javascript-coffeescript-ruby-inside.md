---
title: "Codewars service (with JavaScript, CoffeeScript, Ruby inside)"
tags: "codewars,coffeescript,javascript,online,ruby,Рекомендую"
date: "2013-12-11"
---

![](images/Screenshot-2013-12-11-21.55.06-300x135.png "Screenshot 2013-12-11 21.55.06")

Extremely recommended to try [codewars.com](https://www.codewars.com/dashboard "codewars"). It's the place where you can check and train your skills. Also look and compare you results with other solutions.
