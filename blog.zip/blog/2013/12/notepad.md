---
title: "Browser to Notepad in one click"
tags: "browser,notepad"
date: "2013-12-07"
---

Just do [click](data:text/html, 20%3Chtml%20contenteditable%3E%3Chead%3E%3Ctitle%3ENotepad%3C%2Ftitle%3E%3C%2Fhead%3E%3C%2Fhtml%3E%3Cstyle%20type%3D%22text%2Fcss%22%3E.e%7Bposition%3Aabsolute%3Btop%3A0%3Bright%3A0%3Bbottom%3A0%3Bleft%3A0%3B%7D%3C%2Fstyle%3E%3Cdiv%20class%3D%22e%22%20id%3D%22editor%22%3E%3C%2Fdiv%3E%3Cscript%20src%3D%22http%3A%2F%2Fd1n0x3qji82z53.cloudfront.net%2Fsrc-min-noconflict%2Face.js%22%20type%3D%22text%2Fjavascript%22%20charset%3D%22utf-8%22%3E%3C%2Fscript%3E%3Cscript%3Evar%20e%3Dace.edit(%22editor%22)%3Be.setTheme(%22ace%2Ftheme%2Fmonokai%22)%3Be.getSession().setMode(%22ace%2Fmode%2Fjavascript%22)%3B%3C%2Fscript%3E "click here").

You can save this link to your bookmarks and/or customise it by own taste. Code and comments you can find [here](https://gist.github.com/stevermeister/7846746 "gist").
