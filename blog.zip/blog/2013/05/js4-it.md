---
title: "js4.it"
tags: "blog,Возможно будет интересно"
date: "2013-05-12"
---

решил сделать javascript-ориентированный алиас-домен, добро пожаловать [js4.it/blog](https://js4.it/blog)
