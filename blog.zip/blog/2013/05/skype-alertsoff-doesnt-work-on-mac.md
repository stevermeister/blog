---
title: "Skype /alertsoff doesn't work on Mac"
tags: "alersoff,mac,skype"
date: "2013-05-29"
---

make repost of [this bug](https://community.skype.com/t5/Mac-Linux/alertsoff-doesn-t-work-Skype-team-please-fix-the-bug/m-p/797460/highlight/true#M11448), because there is still no response.

**_I'm participating in some groups. I try to turn off any notification and sounds in this group._**

**_I tested /alertsoff on Lion and Win7. It works correctly on Win7, but doesn't work on Lion. I see notifications in Dock. Please see the screenshot._**

 ![](images/eOYdCaPOY.png)

if somebody knows how to solve it - please help.
