---
title: "Marathon JavaScript Quiz"
tags: "Рекомендую"
date: "2013-05-31"
---

Для разминки мозгов крайне рекомендую - [Marathon JavaScript Quiz](https://alpteam.pl/IT/js_quiz/), сразу скажу - на данный момент содержит опечатки.
