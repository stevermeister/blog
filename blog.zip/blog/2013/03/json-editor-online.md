---
title: "JSON Editor Online"
tags: "editor,json,online,Рекомендую"
date: "2013-03-25"
---

Понравился [сервис](https://www.jsoneditoronline.org/) для просмотра/редактирования JSON. Отличительная черта от подобных сервисов - можно быстро фиксить ошибки в невалидном формате.

[![](images/json_editor_online-300x110.png "json_editor_online")](https://stepansuvorov.com/blog/wp-content/uploads/2013/03/json_editor_online.png)

Также можно отрывать JSON по URL и сохранять результат.
