---
title: "Karma(new name for Testacular)"
tags: "javascript,karma,testacular"
date: "2013-03-19"
---

**Testacular** from [v0.8.0 (2013-03-18)](https://github.com/karma-runner/karma/blob/master/CHANGELOG.md#v080-2013-03-18) is called **[Karma](https://karma-runner.github.com/0.8/index.html)**.
