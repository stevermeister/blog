---
title: "Bootstrap иконки"
tags: "bootstrap,icons,Рекомендую"
date: "2013-03-29"
---

![](images/bootstap_icons-300x214.png "bootstap_icons")

Много кто использует **CSS** от [bootstrap](https://twitter.github.com/bootstrap/index.html), но мало кто встроеный [набор иконок](https://twitter.github.com/bootstrap/base-css.html#icons). Это довольно удобно.

UPD: Также в тему [Font Awesome](https://fortawesome.github.com/Font-Awesome/).
