---
title: "ColorPicker for Mac to get hex"
tags: "ColorPicker,mac,Рекомендую"
date: "2013-09-30"
---

![](images/colorPicker1.png "colorPicker")

Simple and useful [ColorPicker application](https://www.robinwood.com/Catalog/Technical/OtherTuts/MacColorPicker/ColorPicker.zip) plus [hex-plugin](https://wafflesoftware.net/hexpicker/) (installation: just unpack and copy to  ~/Library/ColorPickers/)
