---
title: "Online piano with keyboard melodies"
tags: "online,piano,Рекомендую"
date: "2013-09-30"
---

![](images/Screen-Shot-2013-09-30-at-9.08.01-AM-300x105.png "piano online")

Liked the [Virtual Piano](https://www.virtualpiano.net/) piano online service. Comparing to other similar ones it has lots of keyboard "tabs", so if you type fast - you can play without notes knowledge.
