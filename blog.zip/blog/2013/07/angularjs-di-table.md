---
title: "Таблица внедрения зависимостей между сущностях AngularJS"
tags: "AngularJs,javascript"
date: "2013-07-10"
---

[![](images/Angualr-DI-300x67.png "Angualr DI")](https://stepansuvorov.com/blog/wp-content/uploads/2013/07/Angualr-DI.png)

По вертикали: сущности, которые инжектятся По горизонтали: сущности, в которые происходит инжект
