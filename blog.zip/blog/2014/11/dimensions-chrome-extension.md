---
title: "Dimensions - one more useful chrome extension"
tags: "chrome,extension,tool,Рекомендую"
date: "2014-11-14"
---

[![](images/uHphyxS81tOeXtz2EtPAJNVOTQXIhjzgZzN5Zl7nZlw.png "dimensions chrome extension")](https://felixniklas.com/dimensions/)

[Dimensions](https://felixniklas.com/dimensions/) - pretty useful browser extension for measurement checking.
