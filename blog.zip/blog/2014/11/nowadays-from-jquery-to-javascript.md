---
title: "Nowadays: From jQuery to JavaScript"
tags: "javascript,jQuery,Рекомендую"
date: "2014-11-07"
---

[![](images/Screenshot-2014-11-07-16.29.36.png "you might not need jquery")](https://youmightnotneedjquery.com/ "https://youmightnotneedjquery.com/")

If you are **_jQuery-coder_** but would like to become real **JavaScript Engineer**, [Youmightnotneedjquery](https://youmightnotneedjquery.com/ "https://youmightnotneedjquery.com/") is good resource for you.
