---
title: "@AngularAir"
tags: "AngularAir,AngularJs,javascript,podcast,Рекомендую"
date: "2014-11-15"
---

[![](images/logo1-300x300.png "Angular Air")](https://ng-air.github.io/)

Would like to share link to site with AngularJS podcast announcements that named as [Angular Air](https://ng-air.github.io/). Second podcast is coming...
