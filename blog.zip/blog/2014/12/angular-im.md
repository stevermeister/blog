---
title: "Angular.im"
tags: "angular.im,AngularJs,gitter,skype,Рекомендую"
date: "2014-12-05"
---

![Screenshot 2014-12-05 16.25.55](images/Screenshot-2014-12-05-16.25.55.png)

**AngularJS UA** группа переехала из **skype** в **[gitter](https://gitter.im "gitter.im")**, и теперь может быть найдена по следующему адресу - [angular.im](https://angular.im "angular.im").
