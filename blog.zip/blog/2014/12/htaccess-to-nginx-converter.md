---
title: "htaccess to nginx converter"
tags: "apache,htaccess,nginx,online,tool,Рекомендую"
date: "2014-12-13"
---

Everything that you need is already in internet. I made sure about it one more time when found this service - [htaccess to nginx converter](https://winginx.com/en/htaccess) - it was really helpful for rewriting rules.
