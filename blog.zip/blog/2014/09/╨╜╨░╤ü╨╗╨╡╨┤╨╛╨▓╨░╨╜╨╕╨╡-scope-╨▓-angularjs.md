---
title: "Наследование scope в AngularJS"
tags: "AngularJs,javascript,prototype,scope"
date: "2014-09-10"
---

Думал накидать статью на эту тему, а потом внезапно обнаружил очень [хороший материал](https://github.com/angular/angular.js/wiki/Understanding-Scopes "Understanding Scopes") на angular-wiki и [перевод](https://habrahabr.ru/post/182670/) на хабре, ну и [обсуждение](https://stackoverflow.com/questions/14049480/what-are-the-nuances-of-scope-prototypal-prototypical-inheritance-in-angularjs "stackoverflow.com") на стеке.
