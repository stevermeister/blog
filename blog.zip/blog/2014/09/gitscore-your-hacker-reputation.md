---
title: "gitscore. your hacker reputation"
tags: "github,online,score,tool,Рекомендую"
date: "2014-09-07"
---

[![](images/Screenshot-2014-09-07-14.41.59.png "gitscore")](https://gitscore.com/)

was going to create something like this, but suddenly found that it's already created.
