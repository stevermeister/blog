---
title: "StudyTube V2 Live"
tags: "courses,online,StudyTube,Рекомендую"
date: "2014-09-15"
---

Finally! We are LIVE now. Welcome to [#Studytube](https://www.studytube.nl/ "StudyTube") - the #online learning platform, for now consists of 6 web-app that are made with love and AngularJS.

[![](images/Studytube_logo.png "Studytube_logo")](https://stepansuvorov.com/blog/wp-content/uploads/2014/09/Studytube_logo.png)
