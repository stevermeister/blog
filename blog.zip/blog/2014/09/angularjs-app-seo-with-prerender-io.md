---
title: "AngularJS app SEO with Prerender.io"
tags: "AngularJs,Prerender.io,seo,Рекомендую"
date: "2014-09-08"
---

[![](images/lkYf_5kkT7OvEP4se04gNx4MEiLwCTsN5P5sWWxyEkw.png "prerender.io logo")](https://prerender.io/)

[Prerender.io](https://prerender.io/) - quite useful service to make your **asynchronous** single page application parseable  by **search crawlers**. It's installed like proxy that detects search-bots by header and provides static content from cache.
