---
title: "WebRTC Video Chat"
tags: "online,webrtc,Рекомендую"
date: "2014-04-03"
---

Probably you've already seen this **[vide-chat](https://apprtc.appspot.com)** based on **WebRTC**, but just in case I'll post link here.
