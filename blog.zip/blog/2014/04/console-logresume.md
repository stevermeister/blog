---
title: "console.log(resume)"
tags: "console,IT Рынок"
date: "2014-04-01"
---

По случаю первого апреля создал [резюме в консоле](https://js4.it).
