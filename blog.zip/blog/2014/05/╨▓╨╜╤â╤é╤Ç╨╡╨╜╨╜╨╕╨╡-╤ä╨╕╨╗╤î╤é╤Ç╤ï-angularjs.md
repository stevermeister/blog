---
title: "Внутренние фильтры AngularJS"
tags: "AngularJs,filters,javascript"
date: "2014-05-27"
---

Решил сделать заметку со списком  вспомогательных фильтров AngularJs:

- currency
- date
- filter
- json
- limitTo
- lowercase
- number
- orderBy
- uppercase

[Вот](https://jsfiddle.net/STEVER/wC6up/ "jsfiddle") пример, в котором собрал все фильтры.
