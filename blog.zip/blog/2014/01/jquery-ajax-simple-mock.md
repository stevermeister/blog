---
title: "jQuery Ajax Simple Mock"
tags: "ajax,jQuery,mock,Рекомендую"
date: "2014-01-21"
---

[jQuery Ajax Simple Mock](https://gist.github.com/cowboy/1371254) from [Cowboy](https://github.com/cowboy) to bookmarks.
