---
title: "Viber for Desktop"
tags: "desktop,mac,viber,windows,Рекомендую"
date: "2014-01-08"
---

![](images/viber-300x300.png "viber")

Suddenly realised that now we have **[Viber](https://www.viber.com/) Desktop Client**! I have been waiting for this since their first release.
