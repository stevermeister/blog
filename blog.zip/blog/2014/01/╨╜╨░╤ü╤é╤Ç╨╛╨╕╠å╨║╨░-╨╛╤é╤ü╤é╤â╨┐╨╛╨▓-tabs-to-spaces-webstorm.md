---
title: "Настройка отступов (tabs to spaces) WebStorm"
tags: "indent,phpStorm,space,tab,webStorm,пробел"
date: "2014-01-24"
---

```
Settings -> Code Style -> General -> Tabs and Indents
```

- **Indent** - отступ
- **Continuation indent** - отступ, если следующая строка продолжает предыдущую строку
