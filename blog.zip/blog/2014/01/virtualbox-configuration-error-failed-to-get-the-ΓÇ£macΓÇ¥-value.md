---
title: "VirtualBox - Configuration error: Failed to get the “MAC” value"
tags: "fix,virtualbox"
date: "2014-01-09"
---

Hint to fix this issue.

Go to Settings > Network > Advanced and change the network adapter to PCnet-FAST III.
