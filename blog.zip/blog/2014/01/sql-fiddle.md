---
title: "SQL Fiddle"
tags: "mysql,online,sql,Рекомендую"
date: "2014-01-16"
---

![fiddle logo](images/fiddle_transparent.png "fiddle_transparent")

[SQL Fiddle](https://sqlfiddle.com/) - еще один онлайн инструмент, который можно добавить в закладки. Неплохая песочница для **SQL**.
