---
title: "Keyboard shortcuts for Text Editors"
tags: "shortcuts,Рекомендую"
date: "2014-01-09"
---

_[Shortcuts](https://support.google.com/drive/answer/179738?hl=en "Shortcuts list from Google Docs") make you more efficient._
