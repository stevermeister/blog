---
title: "2048 - nice brain teaser"
tags: "brain teaser,Рекомендую"
date: "2014-03-12"
---

[![](images/Q0Y-_Skolhp9Co1zjmQODhJEXccvuBG3stq9U8rCfoY-297x300.png "Q0Y-_Skolhp9Co1zjmQODhJEXccvuBG3stq9U8rCfoY")](https://gabrielecirulli.github.io/2048/)

[Try](https://gabrielecirulli.github.io/2048/) to get "2048" tile!
