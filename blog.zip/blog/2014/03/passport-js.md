---
title: "Passport.js авторизация для node.js"
tags: "javascript,node.js,psssport.js,Рекомендую"
date: "2014-03-25"
---

![](images/logo-90px.png "passport.js logo")

Внезапно для себя обнаружил опенсорс проект [Passport.js](https://passportjs.org/) — это middleware для авторизации под **node.js**. Которое позволяет "из коробки" авторизироваться в большинстве современных онлайн сервисов (на данным момент больше 140 различных стратегий: такие как **Facebook**, **Twitter**, **Github**).
