---
title: "Скорочтение по технологии spritz"
tags: "spritz,Рекомендую,скорочтение"
date: "2014-03-30"
---

[![squirt logo](images/logo.png "squirt")](https://www.squirt.io/)

[Squirt](https://www.squirt.io/) - технология скорочтения. Есть реализация в виде [кнопки-закладки](https://www.squirt.io/install.html) браузера, которая позволяет выделить на сайте произвольный текст и запустить его в режиме скоростного чтения.
