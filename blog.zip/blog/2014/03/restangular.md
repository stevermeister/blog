---
title: "RestAngular"
tags: "AngularJs,javascript,ngResource,REST,RestAngular,Рекомендую"
date: "2014-03-02"
---

[RestAngular](https://github.com/mgonto/restangular "restangular on github") - mature-REST service for AngualrJS that could be great alternative to [ngResource](https://docs.angularjs.org/api/ngResource).
