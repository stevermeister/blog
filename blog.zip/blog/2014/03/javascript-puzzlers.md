---
title: "JavaScript Puzzlers"
tags: "javascript,quiz,Рекомендую"
date: "2014-03-31"
---

[JavaScript Puzzlers](https://javascript-puzzlers.herokuapp.com/ "JavaScript Puzzlers") to challenge your brain and check JavaScript skills.
