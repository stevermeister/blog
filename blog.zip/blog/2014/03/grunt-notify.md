---
title: "grunt-notify"
tags: "grunt,grunt-notify,javascript,Рекомендую"
date: "2014-03-01"
---

![](images/4e63bf88-0814-11e3-8b57-e2f5f4c2e1c1-300x75.png "grunt-notify-screen")

[grunt-notify](https://github.com/dylang/grunt-notify) - pretty useful **grunt** plugin that provides the adapter to **notification-manager** for your custom events. For example: you are doing TDD - it could inform you when tests-status switches from FAIL to SUCCESS or back. It is supported by all operational systems.
