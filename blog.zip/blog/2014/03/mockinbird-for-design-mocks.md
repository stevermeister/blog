---
title: "Mockinbird for design mocks"
tags: "design,mocks,online,tool,Рекомендую"
date: "2014-03-04"
---

![](images/Screenshot-2014-03-04-22.32.42-300x213.png "mockbird screen")

[Mockinbird](https://gomockingbird.com/mockingbird/) is online tool for creating design mocks, looks friendly for me.
