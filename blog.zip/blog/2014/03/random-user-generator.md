---
title: "Random User Generator"
tags: "images,json,lorem ipsum,online,tool,Рекомендую"
date: "2014-03-01"
---

[randomuser.me](https://randomuser.me/) - nice "_lorem ipsum_"-user API, also with avatar-images.
