---
title: "The Open Graph (OG) protocol"
tags: "html,og,open graph,protocol"
date: "2014-07-05"
---

[![](images/logo.png "logo open graph")](https://ogp.me/)

Только сейчас узнал, что есть способ дать фейсбуку(и другим социальным сервисам) понять какое превью изображение выводить в случае ссылки на ваш сайт. Как оказалось этому посвящен целый протокол - [Open Graph](https://ogp.me/). Вся информация передается в html meta-тэгах:

```html 
  <meta property="og:title" content="The Rock" /> <meta property="og:type" content="video.movie" /> <meta property="og:url" content="https://www.imdb.com/title/tt0117500/" /> <meta property="og:image" content="https://ia.media-imdb.com/images/rock.jpg" />  
 ```

Более подробно подробно - на оф сайте.
