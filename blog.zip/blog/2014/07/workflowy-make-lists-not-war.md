---
title: "Workflowy. Make Lists. Not War"
tags: "list,online,tool,Рекомендую"
date: "2014-07-03"
---

[![](images/WorkFlowy1.png "WorkFlowy")](https://workflowy.com/invite/f26d732.emlx)

I've started with [Workflowy](https://workflowy.com/invite/f26d732.emlx) more then year ago and still have been using this convenient tool, strongly recommend.
