---
title: "How to update the git fork"
tags: "git,git-fork"
date: "2014-07-09"
---

[bash] git remote add upstream https://github.com/whoever/whatever.git git fetch upstream git checkout master git rebase upstream/master [/bash]
