---
title: "Меня просто умиляют творения на чистом CSS"
tags: "css,Рекомендую"
date: "2014-07-03"
---

[JS Bin](https://jsbin.com/sobozire/1/embed?output)
<script type="text/javascript" src="https://static.jsbin.com/js/embed.js"></script>

всех можете найти [тут](https://pattle.github.io/simpsons-in-css/).
