---
title: "GitHub Linker - useful Chrome extension"
tags: "Uncategorized"
date: "2014-10-30"
---

[![](images/Screenshot-2014-10-29-11.12.52.png "github linker chrome extension")](https://chrome.google.com/webstore/detail/github-linker/jlmafbaeoofdegohdhinkhilhclaklkp "GitHub Linker")

[GitHub Linker](https://chrome.google.com/webstore/detail/github-linker/jlmafbaeoofdegohdhinkhilhclaklkp "chrome.google.com") makes more convenient to browse threw all your **bower**, **npm** and **composer** project dependencies on github.
