---
title: "ngMario - AngularJS hints from Mario"
tags: "AngularJs,game,javascript,mario,online,Рекомендую"
date: "2014-10-01"
---

[![](images/kddtu1Emu2wB-2aMwiz2DuPbl7Gt9FnciwMFIK_DL6s1-300x232.png "ngmario")](https://blnight.github.io/ngMario)
