---
title: "Octane - Browser (javascript engine) benchmark"
tags: "benchmark,browser,engine,javascript,octane,Рекомендую"
date: "2014-02-08"
---

test your **browser** **javascript** **engine** with **[Octane 2.0](https://octane-benchmark.googlecode.com/svn/latest/index.html "octane-benchmark")** from **Google**.
