---
title: "WebStorm: Editing HTML Inside of JS Literals"
tags: "editor,html,webStorm"
date: "2014-02-16"
---

![](images/Screenshot-2014-02-16-21.19.36-300x116.png "webstorm html inner edit")

I just got known that **WebStorm** has such a nice possibility to **edit HTML** that is presented like a string (in JavaScript code) in separate window. All you need to do is press **[Alt]**+**[Enter]** and vuala:

[![](images/Screenshot-2014-02-16-21.25.10.png "webstorm html inner edit")](https://stepansuvorov.com/blog/wp-content/uploads/2014/02/Screenshot-2014-02-16-21.25.10.png)
