---
title: "ES6 examples"
tags: "es6,fiddle,javascript,online,Рекомендую"
date: "2014-02-21"
---

You can try ES6 Examples on [es6fiddle.net](https://www.es6fiddle.net/).
