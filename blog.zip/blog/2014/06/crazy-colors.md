---
title: "Crazy-colors - playing random-color blocks on pure JS"
tags: "javascript"
date: "2014-06-15"
---

[![](images/Screenshot-2014-06-15-14.26.27-300x149.png "Screenshot 2014-06-15 14.26.27")](https://stepansuvorov.com/useIt/crazy-colors/)

[Demo](https://stepansuvorov.com/useIt/crazy-colors/) & [Code](https://github.com/stevermeister/crazy-colors "github").

Check your browser capacity ;)
