---
title: "ng-inspector for Chrome & Safari"
tags: "AngularJs,batarang,javascript,ng-inspector,Рекомендую"
date: "2014-06-05"
---

[![](images/ng-inspector.png "ng-inspector")](https://ng-inspector.org/)

Finally we have alternative for [Angular-Batarang](https://github.com/angular/angularjs-batarang), it is [ng-inspector](https://ng-inspector.org/) that works not only for Chrome but also for Safari. First impression of using **ng-inspector** - looks much more UI-friendly than Batarang.
