---
title: "Do Not just copy paste the code!"
tags: "code,javascript,quiz,Рекомендую"
date: "2018-01-18"
---

```javascript
var aﾠ = 1;
var a = 2;
var ﾠa = 3;
if(aﾠ==1 && a== 2 &&ﾠa==3) {
 console.log("Why hello there!")
}
```

[source](https://stackoverflow.com/a/48274520/274500)
