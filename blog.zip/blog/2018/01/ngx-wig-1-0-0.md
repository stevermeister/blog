---
title: "ngx-wig: 1.0.0"
tags: "Angular,javascript,ngx-wig,wysiwyg,Рекомендую"
date: "2018-01-26"
---

![](images/33888069-37bde1f0-df4c-11e7-993e-d48ffe0fffbf.png)

[ngx-wig](https://github.com/stevermeister/ngx-wig) _ opensource lightweight WYSIWYG editor for Angular.

I've just merged pull request with tests and we are ready to go.

# Finally, release!

P.S.: thanks a lot @**[bampakoa](https://github.com/bampakoa)** for the contribution!
