---
title: "Dutch Tax Income Calculator: Now with offline mode"
tags: "income,tax,tool,Uncategorized"
date: "2018-10-14"
---

Finally I found some time to implement **service workers** that will allow you to use application even there is no internet connection. [Check it out](https://thetax.nl/)!

Also it's already **PWA application**, so you can make a shortcut for your mobile desktop:

![](images/Screen-Shot-2018-10-14-at-18.46.31.png)
