---
title: "Six Degrees of Wikipedia - find the shortest path"
tags: "wiki,Рекомендую"
date: "2018-06-07"
---

[**Six Degrees of Wikipedia**](https://www.sixdegreesofwikipedia.com/) shows you the shortest path from one definition to another.

For example, to get from **[Cat](https://en.wikipedia.org/wiki/Cat)** to **[Singularity](https://en.wikipedia.org/wiki/Singularity)** it took only 4 steps and 8 seconds! ![](images/Screen-Shot-2018-06-07-at-10.11.26.png)
