---
title: "Node Frameworks"
tags: "javascript,node.js,Рекомендую"
date: "2017-10-07"
---

[![](images/Screen-Shot-2017-10-07-at-14.51.48.png)](https://nodeframework.com/)

just a bookmark for list of frameworks.

Now I'm in process of looking something suitable for our project.

- [Koa2](https://github.com/koajs/koa) - too hipster, good for learning
- [express](https://expressjs.com/) - old but still green
- [loopback](https://loopback.io/) - good env and tooling, too much abstraction
- [nestjs](https://github.com/nestjs/nest) - typescript, decorators, very Angular-like one
- ...
