---
title: "chrome://dino/"
tags: "chrome,dino,Рекомендую"
date: "2017-10-05"
---

![](images/Screen-Shot-2017-10-05-at-16.41.09.png)

The best chrome update ever. [Now](chrome://dino/) you don't need to wait till internet connection is down.
