---
title: "Google records and store your voice"
tags: "google,google-history,google-now,Возможно будет интересно"
date: "2017-01-06"
---

I knew that google tracked everything you did with your phone, but I did not expect that they also store all the voice messages that goes through voice recognition service, you can find(and listen!) all [here](https://myactivity.google.com/myactivity?restrict=vaa), and btw delete them as well.
