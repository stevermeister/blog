---
title: "VSCode + plunker = Stackblitz"
tags: "online,plunker,tool,vscode,Рекомендую"
date: "2017-08-06"
---

![](images/1-bJZ1jxe67v9mAuNJOho_VQ.gif)

[**Stackblitz**](https://stackblitz.com) is nice combination of **VSCode** experience with **plunker** sandbox.

Some killer features:

- shortcuts (for example cmd+P)
- autocompletion
- npm packages
- debug + live reload is possible in separate window
- works offline
