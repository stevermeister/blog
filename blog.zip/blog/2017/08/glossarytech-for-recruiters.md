---
title: "glossarytech for recruiters"
tags: "recruitment,Рекомендую"
date: "2017-08-28"
---

[![](images/Screen-Shot-2017-08-27-at-22.28.51.png)](https://glossarytech.com/)

Finally there is a place where all recruiters can go and check the difference between Java and Javascript.

Also guys from **glossarytech** have created **[CV scanner](https://glossarytech.com/scanner)**, so basically you don't need to check word by word anymore, just scan the whole CV and get the hints. Nice job!
