---
title: "Git standup to prepare your notes"
tags: "git,scrum,standup,terminal,tool,Рекомендую"
date: "2017-04-22"
---

When you have several projects and lots of small tasks it's easy to forget something important for standup. [**git standup**](https://github.com/kamranahmedse/git-standup) [](https://github.com/kamranahmedse/git-standup) command will help you with quick commit notes for X period of time.

[![](images/687474703a2f2f692e696d6775722e636f6d2f77796f347339452e676966.gif)](https://github.com/kamranahmedse/git-standup)
