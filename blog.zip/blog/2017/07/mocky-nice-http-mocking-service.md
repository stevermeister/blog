---
title: "Mocky - nice HTTP mocking service"
tags: "API,mock,Рекомендую"
date: "2017-07-26"
---

I found easy to use mocking service - **[Mocky](https://www.mocky.io/)** - that allows you to check not only with fixed response for GET/POST..., but also to emit any HTTP error and setup custom header.
