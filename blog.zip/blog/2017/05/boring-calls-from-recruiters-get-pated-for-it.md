---
title: "Boring calls from Recruiters? Get pated for it!"
tags: "IT Рынок,phone,recruitment"
date: "2017-05-18"
---

Answering 100500 times the same stupid questions via phone (taking in account that all this information is presented on the linkedIn profile) makes me mad.

It's not possible to conceal your phone number, sooner or later it will appear in one of call-maniac agencies databases.

I also tried to setup a kind of phone firewall for unknown numbers, but it also not a solution because there is probability that you will miss important call.

And finally I came to idea of setting up [premium-rate](https://en.wikipedia.org/wiki/Premium-rate_telephone_number) phone number and placing it everywhere together with profile. So we kill two birds with one stone: filter recruiters that even don't know you and don't want to read the profile before call, and also get some money for this boring time.

Unfortunately it's not that easy to arrange such kind of number and it's quite expensive. So if you have any idea how to do it - please share.
