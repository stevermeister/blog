---
title: "JSFuck or how I love Javascript endless power"
tags: "javascript,jsfuck,Рекомендую"
date: "2017-06-17"
---

You can write your JS code without any alphabet character, seriously! I would say even more you can write your JS code only with 6! characters: []()!+

You could easily get several string like "true", "false", "undefined" and other by doing simple operations with brackets:

https://gist.github.com/stevermeister/973777cb79b9c41162efa70b2476c5c9

and now you can take any letter :

https://gist.github.com/stevermeister/3ea1b72972dfd8eb053aa0bac47f1138

You can try to challenge yourself and convert any JS code into this format (that is called JSFuck) and there is even [online converter](https://www.jsfuck.com/) that will help you with this task.
