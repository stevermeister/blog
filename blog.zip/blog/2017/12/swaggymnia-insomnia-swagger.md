---
title: "swaggymnia  => insomnia + swagger"
tags: "insomnia,swagger,swaggymnia,Рекомендую"
date: "2017-12-17"
---

![](images/main.png)

If you are still not familiar with **[insomnia](https://insomnia.rest/)**, let me recommend you to have a look.

But that's not all! Now there is an addon for **[swagger](https://swagger.io/)** for easy API endpoints import - **[swaggymnia](https://github.com/mlabouardy/swaggymnia)**:

![](images/insomnia.png)
