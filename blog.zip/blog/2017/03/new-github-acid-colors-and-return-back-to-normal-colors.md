---
title: "New github acid colors ... and return back to normal colors"
tags: "github"
date: "2017-03-01"
---

Do you see the same what I see right now? I don't know why but github team decided to change link color and folder color to ugly acid blue.

![](images/Screen-Shot-2017-03-01-at-21.26.29.png)

Hardly got used to it and decided to create [userscript](https://github.com/stevermeister/userscripts/blob/master/github-old-colors.user.js) to return the normal color. You are welcome to contribute.

![](images/Screen-Shot-2017-03-01-at-21.33.25.png)

To install userscript you can use [Tampermonkey google extension](https://chrome.google.com/webstore/detail/tampermonkey/dhdgffkkebhmkfjojejmpbldmpobfkfo?hl=en).
