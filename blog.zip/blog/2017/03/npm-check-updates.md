---
title: "npm-check-updates"
tags: "ncu,npm,npm-check-updates,tool"
date: "2017-03-15"
---

Just discovered pretty handy npm package that makes quick review for all your project outdated extensions:

$ npm i npm-check-updates -g

and you will get:

![](images/Screen-Shot-2017-03-15-at-22.45.17.png)
