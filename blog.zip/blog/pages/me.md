---
title: me
description: blog description
tags: "stevermeister"
date: "2013-01-02"
---

# Stepan (aka stevermeister) Suvorov

Hello Everyone! 

My name is Stepan Suvorov,
I did my masters in Information security 
and now I’m working in Web Development as a CTO @ Studytube
Doing programming for many years. Only focused on Javascript for 9 years, and with Angular from 2013. I write a blog and lead online Angular courses for RU community, sometimes do in-company training, enjoy teaching and making other developers better.


[![gibhub](./images/gihub.png)](https://github.com/stevermeister)
[![twitter](./images/twitter.png)](https://twitter.com/stevermeister)
[![cv](./images/cv.png)](https://stepansuvorov.com/blog/pages/cv)


*Sorry, dear recruiters no direct contact information here ;) I would like to see enough motivation from you to contact exactly me, but not just sending template message*