---
title: projects
description: blog description
tags: "projects"
date: "2013-01-02"
---



* [Dutch Income Tax Calculator](https://thetax.nl/) - old good AngularJs + ServiceWorkers
* [ngx-wig](https://github.com/stevermeister/ngx-wig) – lightweight Angular WYSIWYG editor
* [ngx-cookie-service](https://github.com/stevermeister/ngx-cookie-service)
* mousometer – just for fun, to check the speed of you mouse
* timer, randomcard,  getdistance, getyouip – tiny helpers
* ...
* [this blog](https://github.com/stevermeister/blog)
