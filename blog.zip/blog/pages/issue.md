---
title: Found an issue?
tags: "issue"
date: "2013-01-02"
---

Did you find an issue: misprint, problems with code, links, formating?
Please create an [issue](https://github.com/stevermeister/blog/issues). I'll try to fix it asap.

Do you know how GitHub works? Great! Maybe you can even do a Pull Request with suggested change?