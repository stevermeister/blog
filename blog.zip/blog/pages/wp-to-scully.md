---
title: 'How to migrate WordPress to Scully'
description: null
tags: 'WordPress,Scully,wp,migration'
date: '2020-06-10'

---

I moved my article to **inDepth** blog - [How to migrate WordPress to Scully](https://indepth.dev/how-to-migrate-wordpress-to-scully/)