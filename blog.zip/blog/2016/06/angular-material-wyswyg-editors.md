---
title: "Angular Material WYSWYG Editors"
tags: "angular-material,AngularJs,javascript,ngwig,wysiwyg,Рекомендую"
date: "2016-06-01"
---

[![Screen Shot 2016-06-01 at 20.40.16](images/Screen-Shot-2016-06-01-at-20.40.16.png)](https://codepen.io/collection/DLepkM/)

[List of WYSWYG Editors](https://codepen.io/collection/DLepkM/) that you can use with Angular Material. Thanks to Tim Brown.
