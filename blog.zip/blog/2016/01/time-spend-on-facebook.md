---
title: "Time spend on Facebook"
tags: "chrome-extension,facebook,Рекомендую"
date: "2016-01-09"
---

![fb timer extension for chrome](images/Screen-Shot-2016-01-08-at-13.49.05.png)

Strictly recommend [this chrome extension](https://chrome.google.com/webstore/detail/time-spend-on-facebook/cbdiihnkhjaiokcaeiecemajlohbhefo?hl=en) that shows you how much time you waste each day stick with FB.
