---
title: "VSCode Slack extension: to send snippets directly from your code"
tags: "slack,vscode,Рекомендую"
date: "2016-12-20"
---

[![](images/icon.png)](https://marketplace.visualstudio.com/items?itemName=sozercan.slack)

[Slack for VSCode](https://marketplace.visualstudio.com/items?itemName=sozercan.slack) - interesting extension I'm playing around which allows you to select some piece of the code and send it to your slack channel directly from editor. Indeed code highlight is missing and channel selection could be more smart, but definitely worth a try.
