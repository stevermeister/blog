---
title: "Get €15 with Booking.com"
tags: "affiliate,booking.com,Рекомендую"
date: "2016-12-14"
---

![](images/Screen-Shot-2016-12-14-at-13.41.57.png)

Booking stats own affiliate program, pretty nice so far: you'll both get **€15 for registration and first hotel reservation**. If you don't have account yet or just want to get €15 you can use my link - https://www.booking.com/s/e166ef98 (and **we both** get €15).
