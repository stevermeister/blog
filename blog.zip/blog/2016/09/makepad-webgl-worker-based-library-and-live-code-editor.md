---
title: "Makepad - webGL worker-based library and live code editor"
tags: "editor,javascript,Makepad,Uncategorized,WebGL"
date: "2016-09-10"
---

[![makepad](images/Screen-Shot-2016-09-10-at-14.05.59.png)](https://makepad.github.io/makepad)

You should definitely have a look at this live editor project "[Makepad](https://github.com/makepad/makepad.github.io)" by [Rik Arends](https://twitter.com/rikarends).
