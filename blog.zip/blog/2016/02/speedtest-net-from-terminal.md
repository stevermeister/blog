---
title: "Speedtest.net from terminal"
tags: "console,speedtest.net,terminal,Рекомендую"
date: "2016-02-06"
---

![speedtest.net from terminal](images/screenshot.gif)

Everything you need is just install npm package:

```
$ npm install --global speed-test
```

and run

```
$ speed-test
```
