---
title: "Idea: Grunt/gulp/webpack config builder"
tags: "config,grunt,online,start me up,tool"
date: "2016-05-07"
---

![grunt-logo](images/grunt-logo.png)![gulp-2x](images/gulp-2x.png)![1-A-_KrEvMuiH7dlwshFw5aw](images/1-A-_KrEvMuiH7dlwshFw5aw.png)

I don't know why such kind of service still have not been invented. It's not only about grunt/gulp or webpack but also about build tools of such kind.

It could be so useful: you just feed your github repo to the service and in step by step wizard create your config file. After all you have pull request with changes(new config file) to your project.
