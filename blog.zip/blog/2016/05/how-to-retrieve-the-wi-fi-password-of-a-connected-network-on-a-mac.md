---
title: "How to Retrieve the Wi-Fi Password of a Connected Network on a Mac"
tags: "mac,password,wi-fi"
date: "2016-05-07"
---

Just a not-to-forget note.

/Applications/Utilities/Keychain Access![E4oNi](images/E4oNi.png)

taken from [here](https://apple.stackexchange.com/a/56132).
