---
title: "Awareness - don't let your PC make you tired"
tags: "app,mac,time-management,Рекомендую"
date: "2016-05-06"
---

[![awareness-bowl](images/awareness-bowl.png)](https://iamfutureproof.com/tools/awareness/)

[Awareness](https://iamfutureproof.com/tools/awareness/) helps you become more aware of time spent on the computer by playing the sound of a Tibetan singing bowl to mark every hour of continuous computer use.

It also displays how long you’ve been using your computer without a break in the menu bar.
