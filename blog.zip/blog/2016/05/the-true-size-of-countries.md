---
title: "The True size of countries"
tags: "map,mercator projection,online,Рекомендую"
date: "2016-05-18"
---

[![Screen Shot 2016-05-18 at 13.06.17](images/Screen-Shot-2016-05-18-at-13.06.17.png)](https://thetruesize.com/)

[Thetruesize](https://thetruesize.com/) opened my eyes to [mercator projection](https://en.wikipedia.org/wiki/Mercator_projection) topic.
