---
title: "Fck Valentine's Day"
tags: "holidays,Вольное творчество"
date: "2012-02-14"
---

[![fck the valentines day](images/fck_valentines_day.png "fck_valentines_day")](https://stepansuvorov.com/blog/2012/02/fck-valentines-day/)

Всем сердечкомишко поклонникам посвящается.

[![](images/%D0%B2%D0%B0%D0%BB%D0%B5%D0%BD%D1%82%D0%B8%D0%BD%D0%BA%D0%B0.jpg "валентинка")](https://stepansuvorov.com/blog/wp-content/uploads/2012/02/%D0%B2%D0%B0%D0%BB%D0%B5%D0%BD%D1%82%D0%B8%D0%BD%D0%BA%D0%B0.jpg)

// тут будет ссылка на автора
