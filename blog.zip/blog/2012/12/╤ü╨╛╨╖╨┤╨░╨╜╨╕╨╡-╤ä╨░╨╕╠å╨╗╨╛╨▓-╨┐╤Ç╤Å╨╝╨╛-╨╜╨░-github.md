---
title: "Создание файлов прямо на GitHub"
tags: "git,github"
date: "2012-12-06"
---

Свершилось! Они сдеали возможность создавать файлы прямо в веб интерфейсе.

![](images/github_createfile-300x87.png "github_createfile")

подробнее на [офсайте](https://github.com/blog/1327-creating-files-on-github).
