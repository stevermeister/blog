---
title: "PHP The Right Way."
tags: "manual,php"
date: "2012-07-29"
---

 [![PHP: The Right Way](images/lg-rect-386x280.png)](https://www.phptherightway.com) 

**worth reading**
