---
title: "Автодополнение к Firebug консоли"
tags: "autocomplete,console,firebug,Firefox"
date: "2012-05-20"
---

Понял что многие разработчики, использующие в своей работе firebug console, не переставляют что к ней появилось дополнение реализующее автокомплит (То что так хорошо работает в Chrome)

Вот оно [Firebug Autocompleter](https://addons.mozilla.org/en-US/firefox/addon/firebug-autocompleter/ "firebug autocomplete addon"), используйте на здоровье.
