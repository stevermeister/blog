---
title: "ThinkPHP - сообществу быть?"
tags: "event,php,Возможно будет интересно"
date: "2012-05-24"
---

Решил опубликовать ссылку на событие: https://thinkphp.com.ua/

["_это мероприятие – первый кирпичик в основание этого сообщества_"](https://anton.shevchuk.name/php/meetup-thinkphp-in-kharkov/ "thinkphp")

Посмотрим что будет.
