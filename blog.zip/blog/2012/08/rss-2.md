---
title: "RSS"
tags: "rss"
date: "2012-08-19"
---

![](images/1345394895_picons20.png "1345394895_picons20")

В связи с тем, что новые статьи стали появляться чаще, рекомендую [RSS](https://stepansuvorov.com/blog/feed/ "rss").
