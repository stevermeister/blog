---
title: "Return to Skype 2.2"
tags: "skype,ubuntu"
date: "2012-08-02"
---

I don't like new **skype 4.0** for **Linux**. I've removed it from **Ubuntu** and was very happy to find old installation **deb** file. If you think the same, here you are:

[skype-ubuntu_2.2.0.35-1_i386.deb](https://stepansuvorov.com/share/skype-ubuntu_2.2.0.35-1_i386.deb)

[skype-ubuntu_2.2.0.35-1_amd64.deb](https://stepansuvorov.com/share/skype-ubuntu_2.2.0.35-1_amd64.deb)
