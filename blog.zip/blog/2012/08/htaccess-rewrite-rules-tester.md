---
title: ".htaccess rewrite rules tester"
tags: "Uncategorized"
date: "2012-08-17"
---

Хочу порекомендовать [сервис для тестирования rewrite rules](https://htaccess.madewithlove.be/) под Apache. Нам на проекте он оказался весьма полезным.
