---
title: "phantomjs: error while loading shared libraries: libfontconfig.so.1"
tags: "phantomjs,ubuntu"
date: "2012-10-22"
---

In case if you want to install phantomjs and you have just console OS without GUI you have to install additional libraries:

sudo apt-get install freetype-devel fontconfig-devel
