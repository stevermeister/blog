---
title: "Skype: P2P connect failed (english)"
tags: "skype,ubuntu"
date: "2012-04-02"
---

_Just because this post turned out to be popular. I made version in English._

![](images/skype_fail.png "skype_fail")

Today I've faced with next problem: Skype didn't want to start for a long time and after I saw a message "P2P connect failed". Skype restart and PC restart didn't solve the problem. Without a second thought  I'd backed up account folder (/home/%username%/.Skype) and made it clean. And it really helped - skype started normally.

If somebody got known what's wrong - put it down in comments please.
