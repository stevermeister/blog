---
title: "Fck Unity!"
tags: "gnome,ubuntu,unity"
date: "2012-09-09"
---

sudo apt-get install gnome-shell
sudo apt-get remove unity

[Alt]+[Win]+[right mouse] - to setup the panel
