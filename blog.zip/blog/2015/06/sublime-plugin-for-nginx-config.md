---
title: "Sublime plugin for nginx config"
tags: "nginx,Sublime,Рекомендую"
date: "2015-06-29"
---

![sublime nginx](images/screenshot.png)

[Nginx Syntax Highlighting Plugin](https://github.com/brandonwamboldt/sublime-nginx) from Brandon Wamboldt. Don't know why it's not yet native for sublime.
