---
title: "Touch Pianist - train your rhythm"
tags: "online,piano,rhythm,Рекомендую"
date: "2015-05-18"
---

[![touch pianist](images/Screenshot-2015-05-18-21.49.48.png)](https://touchpianist.com/)

[Touch Pianist](https://touchpianist.com/) - looks useless, but you could stick to it for hours, trust me.
