---
title: "WrapBootstrap - Source of UX inspiration"
tags: "bootstrap,design,styles,UX,Рекомендую"
date: "2015-05-08"
---

[![wrapbootstrap](images/Screenshot-2015-05-08-11.52.16.png)](https://wrapbootstrap.com/)

I'd already returned back to this service so many times that decided to share. It's a good place to see great examples how you could organise you UI parts in the best way.

remember: Bootstrap can be dangerous for you projects, use it only for prototyping ;)
