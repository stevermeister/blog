---
title: "localtunnel - show your work to anyone"
tags: "localtunnel,node.js,Рекомендую"
date: "2015-05-21"
---

**[localtunnel](http://localtunnel.me/)** - easy way to share your work(local server output) by providing tunnel from your machine to the internet.

All you need to so is run 2 commands:

[shell] $ npm install -g localtunnel $ lt --port 8000 [/shell]

And after you'll get the link to share, something like _https://gqgh.localtunnel.me_
