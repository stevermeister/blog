---
title: "angular-promise-buttons"
tags: "angular-promise-buttons,AngularJs,javascript,Рекомендую"
date: "2015-05-07"
---

![angular promise buttons](images/Screenshot-2015-05-07-11.51.39.png)

[**angular-promise-buttons**](https://github.com/johannesjo/angular-promise-buttons) is a nice module for AngularJS that saves you from toggling the loading indicator each time on button click.

[Here](https://plnkr.co/edit/yKrlohXVL15fRjTjZHBJ?p=preview) I created a sandbox to play with the code.
