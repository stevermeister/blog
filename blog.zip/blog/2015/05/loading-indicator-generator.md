---
title: "cssload.net - loading indicator generator"
tags: "css,design,online,tool,Рекомендую"
date: "2015-05-09"
---

[![cssload_logo](images/cssload_logo.png)](https://cssload.net/)

 

Just select, customise and get CSS presentation for it. Also goes into bookmarks.

![cssload example](images/Screenshot-2015-05-08-19.36.07.png)
