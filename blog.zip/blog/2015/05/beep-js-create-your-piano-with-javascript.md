---
title: "beep.js - Create your piano with JavaScript"
tags: "javascript,online,piano,Рекомендую"
date: "2015-05-04"
---

[![beep.js](images/Screenshot-2015-05-05-22.21.49.png)](https://beepjs.com/)

[Beep.js](https://beepjs.com/) is a JavaScript library for building browser-based synthesizers.
