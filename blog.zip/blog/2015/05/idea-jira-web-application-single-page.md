---
title: "Idea: Jira Web Application (Single Page)"
tags: "Atlassian,idea,jira,spa,start me up"
date: "2015-05-30"
---

![atlassian-jira-logo-large](images/atlassian-jira-logo-large.png)

For me it's pretty strange that the most popular (IMHO) task tracker does not have web application (only webpage). All products hosted by Atlassian is terribly slow! Almost for each action it reloads the page. Nowadays it's not possible to imaging good online service that is not responsive single page.

I hope that they already started working on new version that would be completely single page. Also I could not find any plugin that would cover this possibility.

So basically my idea is to make **Jira SPA** like a core solution, or create a **plugin for Jira** at least for the most used part - **Agile Board**.
