---
title: "Ionic Playground"
tags: "AngularJs,ionic,javascript,online,sandbox,tool,Рекомендую"
date: "2015-05-11"
---

![ionitron-twitter](images/ionitron-twitter.png)

I would only point out how good is **Ionic Team**  in building own environment to make a life of developers easier. Now they created own **sandbox** to play with ionic code.

[![ionic playground](images/Screenshot-2015-05-11-09.28.35.png)](https://play.ionic.io/app/3707d8aa5d7f)
