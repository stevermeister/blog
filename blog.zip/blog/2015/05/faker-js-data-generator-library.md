---
title: "faker.js - data generator library"
tags: "faker.js,javascript,node.js,Рекомендую"
date: "2015-05-20"
---

[![faker.js](images/687474703a2f2f696d6775722e636f6d2f4b69696e512e706e67.png)](https://github.com/marak/Faker.js/)

**[faker.js](https://github.com/marak/Faker.js/)** - javascript library to generate test/mock data, very simple in use, works for browser and node.js. Check on [jsfiddle](https://jsfiddle.net/STEVER/mbahwx0y/).
