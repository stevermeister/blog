---
title: "AngularJS: Синтаксис Controller as"
tags: "AngularJs,ng-controller,scope"
date: "2015-09-16"
---

Решил выложить [пример кода "Controller as" в песочнице](https://plnkr.co/edit/B9YOb3?p=preview), чтобы можно было поиграться и понять, что нельзя миксовать 2 стиля написания контроллеров: либо **$scope** и писать просто переменные, либо **this** и делать синтаксис **Controller as**.
