---
title: "Command-line pro-tips"
tags: "mac,shell,terminal,unix,Рекомендую"
date: "2015-09-15"
---

just put it here (taken from [@addyosmani](https://twitter.com/addyosmani))

![command line pro tips](images/CMoQI_9UEAAseRr.jpg)
