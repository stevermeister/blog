---
title: "RawGit - to get raw files from github by direct link"
tags: "CDN,github,online,tool,Рекомендую"
date: "2015-01-31"
---

[![rawgit logo](images/Screenshot-2015-01-30-21.10.29.png)](https://rawgit.com/)

It's really ingenious.

Prehistory: **GitHub** service forbad option to use its service like **CDN** (by direct linking to source file).

[**RawGit**](https://rawgit.com/ "https://rawgit.com/") service provide proxy to solve this ( so you just need to replace "https://github.com/" to "https://rawgit.com/").
