---
title: "DIT 2015 - Dutch income tax calculator"
tags: "income,online,tax,tool"
date: "2015-01-24"
---

Updated [Dutch income tax calculator](https://stepansuvorov.com/useIt/dit/ "Dutch Income Tax Calculator") for new **2015** tax rates.
