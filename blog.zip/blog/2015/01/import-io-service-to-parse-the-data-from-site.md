---
title: "import.io - service to parse the data from site"
tags: "import.io,online,parse,tool,Рекомендую"
date: "2015-01-17"
---

[![importio](images/importio.png)](https://import.io/)

Probably not mature enough, but could be pretty handy - [import.io](https://import.io/ "https://import.io/")
