---
title: "Rich Famo.us animations in AngularJS directives"
tags: "AngularJs,animation,Famo.us,javascript,Рекомендую"
date: "2015-01-27"
---

[![Famo.us + AngularJS](images/Screenshot-2015-01-27-12.09.45.png)](https://famo.us/integrations/angular/#/intro "https://famo.us/integrations/angular")

**[Famo.us](https://famo.us/integrations/angular/#/intro "https://famo.us/integrations/angular/#/intro")** - not sure that I'll use it for my project, but it looks really fancy.
