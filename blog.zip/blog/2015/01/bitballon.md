---
title: "BitBallon - easy way to share static web-site"
tags: "hosting,online,tool,Рекомендую"
date: "2015-01-26"
---

[![bitballoon-logo](images/T-jkjKUMGZJggAAAABJRU5ErkJggg.png)](https://www.bitballoon.com "https://www.bitballoon.com")

I really like such easy-to-use user friendly services. [BitBalloon](https://www.bitballoon.com "https://www.bitballoon.com") is one of them. Just drag-n-drop your static web-site or web-app and it's ready to be presented.
