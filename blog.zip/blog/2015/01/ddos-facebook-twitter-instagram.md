---
title: "Что случилось с facebook, twitter, Instagram"
tags: "DDos,facebook,Instagram,twitter,Возможно будет интересно"
date: "2015-01-27"
---

По предварительным данных **26 января 2015** крупнейшие социальные сервисы подверглись серьезной **DDoS** атаке, организованной хакерской группировкой **Lizard Squad**.

![facebook-ddos](images/Screenshot-2015-01-27-09.44.25.png)

**UPD:** [digitalattackmap.com](https://www.digitalattackmap.com/%20 "https://www.digitalattackmap.com/ ") - очень красивая визуализации логов **DDos** атак.
