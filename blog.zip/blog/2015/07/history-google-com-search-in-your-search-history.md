---
title: "history.google.com - search in your search history"
tags: "google,online,tool,Рекомендую"
date: "2015-07-29"
---

With google you can search for text, images, videos, location, and many other things. But not you can do search even in your search history! [history.google.com](https://history.google.com) lets you filter by date, get statistic and even delete(_?really_) any record.
