---
title: "'fuck' - command for all the cases"
tags: "console,shell,Рекомендую"
date: "2015-07-21"
---

instead of many words:

[![thefuck console command](images/example.gif)](https://github.com/nvbn/thefuck)
