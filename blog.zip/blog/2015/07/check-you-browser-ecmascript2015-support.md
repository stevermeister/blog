---
title: "Check you browser ECMAScript2015 support"
tags: "Рекомендую"
date: "2015-07-30"
---

[![browser ecmascript 2015 support](images/Ft71h9czOrgKF3e8tTVxnfNHOOjjFl605k2wxmLy1SA.png)](https://ruanyf.github.io/es-checker/)

Simple **ECMAScript2015** support [open-source](https://github.com/ruanyf/es-checker) checker.
