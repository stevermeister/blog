---
title: "Google Chrome crashe log"
tags: "chrome,crashe,log"
date: "2015-07-10"
---

It not very obvious where to find crashes logs in Chrome. First thing that you need to do is make sure that you have logging option ON, you should have check on this option in Chrome setting:

![chrome crashe](images/Screenshot-2015-07-10-13.38.28.png)

Then you can go to

chrome://crashes

Taken from [stackoverflow](https://stackoverflow.com/questions/8764253/google-chrome-crashes-without-any-log), thanks Mahai.
