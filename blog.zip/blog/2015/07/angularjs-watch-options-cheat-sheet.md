---
title: "AngularJS $watch options Cheat Sheet"
tags: "$watch,AngularJs,cheatsheet,javascript"
date: "2015-07-23"
---

quite a nice illustration from ng [ofdoc](https://code.angularjs.org/1.3.17/docs/guide/scope)

![concepts-scope-watch-strategies](images/concepts-scope-watch-strategies.png)
