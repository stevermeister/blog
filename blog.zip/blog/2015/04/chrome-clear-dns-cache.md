---
title: "Chrome clear DNS cache"
tags: "cache,chrome,DNS"
date: "2015-04-09"
---

Found something new for myself when followed by [chrome://net-internals](chrome://net-internals).

To clean-up **DNS** cache you should just select DNS from dropdown and after click the button "Clear host cache":

![clear dropbox cache](images/Screenshot-2015-04-09-10.10.14.png)
