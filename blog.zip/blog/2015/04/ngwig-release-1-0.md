---
title: "ngWig - Release 1.0"
tags: "Angular,javascript,ng-wig"
date: "2015-04-29"
---

[![ng-wig-demo](images/ng-wig-demo.png)](https://stevermeister.github.io/ngWig/ "https://stevermeister.github.io/ngWig/")

We've just updated our **WYSIWYG AngularJS Editor** by removing iframe from it, so [**ngWig**](https://stevermeister.github.io/ngWig/ "https://stevermeister.github.io/ngWig/") became even more light-weight. Welcome to use, test and contribute!
