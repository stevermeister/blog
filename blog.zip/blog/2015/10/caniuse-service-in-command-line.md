---
title: "Caniuse service in command line"
tags: "caniuse,console,terminal,Рекомендую"
date: "2015-10-24"
---

![caniuse in console](images/Screenshot-2015-10-24-20.37.18.png)

[shell] npm install -g caniuse-cmd [/shell]

[Source code](https://github.com/sgentle/caniuse-cmd).
