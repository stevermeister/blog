---
title: "Куда украинцам не нужна виза"
tags: "travel,Ukraine,visa,Рекомендую"
date: "2015-10-25"
---

![visa for Ukrainians](images/Screenshot-2015-10-25-08.23.07.png)

Только подумал создать удобный сервис, а оказалось [такой уже есть](https://visareq.com/visas/UKR.html). (спасибо [Mike Dobrin](https://www.facebook.com/mike.dobrin) за наводку)
